antibody ngs pipeline
